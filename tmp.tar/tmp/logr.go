package tmp

import "log"

func Log(err error) {
	log.Println(err)
}
